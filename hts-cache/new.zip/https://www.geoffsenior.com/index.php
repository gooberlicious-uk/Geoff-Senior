<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/application/themes/geoffsenior/css/bootstrap-modified.css">
    <link href="/application/files/cache/css/geoffsenior/main.css?ts=1738615803" rel="stylesheet" type="text/css" media="all">	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,500,500i,700&amp;subset=latin-ext" rel="stylesheet"> 
	<link href="/application/themes/geoffsenior/css/geoffsenior.css" rel="stylesheet"> 
	<style type="text/css">
		div.ccm-page {
			background-image: url(/application/files/4714/9451/2300/cover1.jpg);
		}
	</style>
    
<title>Home :: Geoff Senior</title>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="generator" content="concrete5 - 8.2.1"/>
<meta name="msapplication-TileImage" content="https://www.geoffsenior.com/application/files/7816/0488/4411/windows.png"/>
<link rel="shortcut icon" href="https://www.geoffsenior.com/application/files/2416/0488/4412/favicon.ico" type="image/x-icon"/>
<link rel="icon" href="https://www.geoffsenior.com/application/files/2416/0488/4412/favicon.ico" type="image/x-icon"/>
<link rel="apple-touch-icon" href="https://www.geoffsenior.com/application/files/1416/0488/4411/apple.png"/>
<script type="text/javascript">
    var CCM_DISPATCHER_FILENAME = "/index.php";
    var CCM_CID = 1;
    var CCM_EDIT_MODE = false;
    var CCM_ARRANGE_MODE = false;
    var CCM_IMAGE_PATH = "/updates/concrete5-8.2.1_remote_updater/concrete/images";
    var CCM_TOOLS_PATH = "/index.php/tools/required";
    var CCM_APPLICATION_URL = "https://www.geoffsenior.com";
    var CCM_REL = "";
</script>

<link href="/updates/concrete5-8.2.1_remote_updater/concrete/css/font-awesome.css" rel="stylesheet" type="text/css" media="all">
<script type="text/javascript" src="/updates/concrete5-8.2.1_remote_updater/concrete/js/jquery.js"></script>
<!--[if lt IE 9]><script type="text/javascript" src="/updates/concrete5-8.2.1_remote_updater/concrete/js/ie/html5-shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script type="text/javascript" src="/updates/concrete5-8.2.1_remote_updater/concrete/js/ie/respond.js"></script><![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
            var msViewportStyle = document.createElement('style');
            msViewportStyle.appendChild(
                document.createTextNode(
                    '@-ms-viewport{width:auto!important}'
                )
            );
            document.querySelector('head').appendChild(msViewportStyle);
        }
    </script>
</head>
<body>

<div class="ccm-page page-type-homepage page-template-full">

<header>
	<div class="container" id="siteTitle">
		

    <a href="https://www.geoffsenior.com/"><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/6914/9483/7173/logo-silver.png" alt="GEOFF SENIOR" class="ccm-image-block img-responsive bID-48"></picture></a>
	</div>
    <div class="container" id="headerNav">
		

    <ul class="nav"><li class=""><a href="https://www.geoffsenior.com/gallery" target="_self" class="">Gallery</a></li><li class=""><a href="https://www.geoffsenior.com/comics" target="_self" class="">Comics</a></li><li class=""><a href="https://www.geoffsenior.com/commissions" target="_self" class="">Commissions</a></li><li class=""><a href="https://www.geoffsenior.com/store" target="_self" class="">Store</a></li><li class=""><a href="https://www.geoffsenior.com/advertising" target="_self" class="">Advertising</a></li></ul>
    </div>
	<div id="headerSocial">
		

    
<div id="ccm-block-social-links149" class="ccm-block-social-links">
    <ul class="list-inline">
            <li><a target="_blank" href="https://www.facebook.com/geoff.senior.50"><i class="fa fa-facebook"></i></a></li>
            <li><a target="_blank" href="https://www.instagram.com/senior.geoff/"><i class="fa fa-instagram"></i></a></li>
            <li><a target="_blank" href="https://twitter.com/geoffsenior4"><i class="fa fa-twitter"></i></a></li>
            <li><a target="_self" href="/contact"><i class="fa fa-envelope-o "></i></a></li>
        </ul>
</div>
	</div>
</header>

<main>
    

<div class="container"><div class="row"><div class="col-sm-12">        <div class="ccm-custom-style-container ccm-custom-style-main-957 textbox-reverse introduction"
            >
    <p><strong>Geoff Senior</strong> has been a professional artist and illustrator for over 35 years. Although most notorious for his work on <strong>Transformers </strong>comic in the 1980s, he has provided artwork for many comic titles including <strong>Action Force</strong>, <strong>Dragon&rsquo;s Claws</strong> and <strong>Judge Dredd</strong>. Geoff also created the <strong>Death&rsquo;s Head</strong> character for Marvel in 1987 with writer Simon Furman.</p>

<p>Since the 1990s Geoff has primarily applied his talents in the advertising world, producing many thousands of storyboard frames, visuals and animations for some award-winning television commercials.</p>

<p>More recently, Geoff has collaborated with longtime cohort, Simon Furman, on the online comic series <strong>To the Death</strong> which has been critically very well received.</p>

</div></div></div>    </div>


<div class="container"><div class="row"><div class="col-sm-12">        <div class="ccm-custom-style-container ccm-custom-style-main-2200 textbox"
            >
    <h2>News</h2>

<p><strong>2026 Comic conventions I&#39;m guesting at:</strong></p>

<p>&nbsp;</p>

<p><strong>TfukCon - Cobden Hotel, Birmingham - 16th May 2026</strong></p>

<p>https://www.primetimetoyz.co.uk/tfukcon</p>

<p>I&#39;ll be drawing ink line sketches there (&pound;40 per figure). If you&#39;d like to pre order/pay and pick up at the con then please do so through&nbsp;</p>

<p>&#39;Commissions&#39; link.</p>

<p>&nbsp;</p>

</div></div></div>    </div>


<div class="container"><div class="row"><div class="col-sm-12">    <div class="row"><div class="col-sm-6">

        <div class="ccm-custom-style-container ccm-custom-style-main183-744 textbox"
            >
    <h2>Killatoa</h2>

<p><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/8315/9587/7747/killatoa_sketch_copy.jpg" alt="killatoa sketch copy.jpg" class="pull-left" style=" margin-right: 30px;" width="200" height="306"></picture></p>

<p><strong>&nbsp;KILLATOA- &#39;on&nbsp;the&nbsp;Origin of Species&#39;</strong> 15 part mini strip- The first solo spin-off from <a href="https://twitter.com/ToTheDeathcomic" target="_blank">@ToTheDeathcomic</a>. <strong>Free to read, share and collect</strong> at <a href="http://to-the-death.com/killatoa/" target="_blank">to-the-death.com/killatoa/</a> &amp; <a href="https://getmycomics.com/" target="_blank">getmycomics.com</a>&nbsp;</p>

<div class="clearfix" style="visibility:hidden;">clear</div>

    </div>
</div><div class="col-sm-6">

        <div class="ccm-custom-style-container ccm-custom-style-main184-2186 textbox"
            >
    <h2>To The Death</h2>

<p><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/1015/9587/8028/TTD_ptone_cover_.jpg" alt="TTD ptone cover .jpg" class="pull-left" style=" margin-right: 30px;" width="200" height="306"></picture></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>All 10 issues of <strong>&#39;To The Death&#39;</strong> are&nbsp; available&nbsp;from:&nbsp;<a href="https://getmycomics.com/ToTheDeath">https://getmycomics.com/ToTheDeath</a></p>

<p>Simon and I are really happy&nbsp;with the quality of the print. Each issue has 48 action packed colour pages and at just <strong>&pound;4.99</strong> is <strong>great value!&nbsp;</strong></p>

<p>For those who remember &#39;<strong>Dragon&#39;s Claws</strong>&#39; it certainly &#39;ticks the boxes&#39;&nbsp;</p>

    </div>
</div></div>
</div></div></div>

<div class="container"><div class="row"><div class="col-sm-12">    <div class="row"><div class="col-sm-4">

        <div class="ccm-custom-style-container ccm-custom-style-main9-114 textbox-reverse"
            >
    <h2>Get your own unique Geoff Senior artwork</h2>

<p><a href="https://www.geoffsenior.com/commissions"><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/4414/9495/1930/commissions.png" alt="comissions.png" class="responsive"></picture></a></p>

<p style="margin-top:15px;"><a class="btn btn-primary" href="https://www.geoffsenior.com/commissions" style="width:100%;">Go to commissions...</a></p>

    </div>
</div><div class="col-sm-8"><div
class="ccm-custom-style-main10 textbox"
>


    <h2 class="feature clearfix"><i aria-hidden="true" class="fa fa-instagram fa-5" style="float:right;font-size:180%;line-height:100%;;vertical-align:middle;"></i>Follow Geoff on Instagram</h2>



    <div id="instafeed"></div>
<script type="text/javascript" src="/application/themes/geoffsenior/js/instafeed.min.js">
</script>
<script type="text/javascript">
    var feed = new Instafeed({
        get: 'user',
        userId: 4835191004,
		accessToken: '4835191004.83c0bf4.593d6172cd4648ecad0e620861370692',
		limit: 8,
		resolution: 'standard_resolution',
		template: '<div class="instagram"><a class="" href="{{link}}"><img src="{{image}}" /></a></div>'
    });
    feed.run();
</script>
</div></div></div>
</div></div></div>

<div class="container"><div class="row"><div class="col-sm-12">    <div class="row"><div class="col-sm-12"><div
class="ccm-custom-style-main11 textbox"
>


    <h2>In the gallery</h2>


        <div class="ccm-custom-style-container ccm-custom-style-main11-453 gallery-preview"
            >

    <div class="row"><div class="col-sm-6">

    <a href="https://www.geoffsenior.com/gallery"><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/3815/0021/6014/Storm_on_Mars.jpg" alt="" class="ccm-image-block img-responsive bID-450"></picture></a>
</div><div class="col-sm-6">

    <a href="https://www.geoffsenior.com/gallery"><picture><!--[if IE 9]><video style='display: none;'><![endif]--><!--[if IE 9]></video><![endif]--><img src="/application/files/9814/9909/8597/gallery-preview2.jpg" alt="" class="ccm-image-block img-responsive bID-449"></picture></a>
</div></div>
    </div>


    <p>Geoff&rsquo;s online portfolio of digital work and traditional paintings. It&#39;s not all robots!</p>

<p style="text-align: right;"><a class="btn btn-primary" href="https://www.geoffsenior.com/gallery">See more...</a></p>

</div></div></div>
</div></div></div>

<div class="container"><div class="row"><div class="col-sm-12">    <div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div>
</div></div></div></main>


<footer id="footer-theme">
            <section>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                                            </div>
                    <div class="col-sm-6">
                        

    
<div id="ccm-block-social-links148" class="ccm-block-social-links">
    <ul class="list-inline">
            <li><a target="_blank" href="https://www.facebook.com/geoff.senior.50"><i class="fa fa-facebook"></i></a></li>
            <li><a target="_blank" href="https://www.instagram.com/senior.geoff/"><i class="fa fa-instagram"></i></a></li>
            <li><a target="_blank" href="https://twitter.com/geoffsenior4"><i class="fa fa-twitter"></i></a></li>
            <li><a target="_self" href="/contact"><i class="fa fa-envelope-o "></i></a></li>
        </ul>
</div>
                    </div>
                </div>
            </div>
        </section>
        
    <section>
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    

    <p><strong>&copy; 2019 Geoff Senior </strong>| This is <a href="http://gooberlicious.co.uk" target="_blank">Gooberlicious</a></p>

                </div>
                <div class="col-sm-3">
                                    </div>
                <div class="col-sm-3">
                                    </div>
            </div>
        </div>
    </section>
</footer>



</div>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/animation.gsap.js"></script>
<script src="/application/themes/geoffsenior/js/geoffsenior.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-8785665-1', 'auto');
  ga('send', 'pageview');

</script><script type="text/javascript" src="/updates/concrete5-8.2.1_remote_updater/concrete/js/picturefill.js"></script>

</body>
</html>
